globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/eW4u2O-oHQjGPlPeUhapw/_buildManifest.js",
    "static/eW4u2O-oHQjGPlPeUhapw/_ssgManifest.js",
    "static/eW4u2O-oHQjGPlPeUhapw/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0l7628x5hic9-.js",
    "static/chunks/16kes2__159u-.js",
    "static/chunks/2wmym2bcmrs6p.js",
    "static/chunks/073augfw4lzl0.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/0l7628x5hic9-.js",
        "static/chunks/16kes2__159u-.js",
        "static/chunks/2wmym2bcmrs6p.js",
        "static/chunks/073augfw4lzl0.js"
      ],
      "runtimeModuleIds": [
        41183
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/0l7628x5hic9-.js",
        "static/chunks/16kes2__159u-.js",
        "static/chunks/2wmym2bcmrs6p.js",
        "static/chunks/073augfw4lzl0.js"
      ],
      "runtimeModuleIds": [
        41183
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/0l7628x5hic9-.js",
        "static/chunks/16kes2__159u-.js",
        "static/chunks/2wmym2bcmrs6p.js",
        "static/chunks/073augfw4lzl0.js"
      ],
      "runtimeModuleIds": [
        41183
      ]
    },
    "/Menu/page": {
      "otherChunks": [
        "static/chunks/0l7628x5hic9-.js",
        "static/chunks/16kes2__159u-.js",
        "static/chunks/2wmym2bcmrs6p.js",
        "static/chunks/073augfw4lzl0.js"
      ],
      "runtimeModuleIds": [
        41183
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
