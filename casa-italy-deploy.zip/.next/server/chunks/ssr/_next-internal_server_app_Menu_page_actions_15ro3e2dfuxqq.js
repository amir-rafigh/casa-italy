module.exports=[16986,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_Menu_page_actions_15ro3e2dfuxqq.js.map