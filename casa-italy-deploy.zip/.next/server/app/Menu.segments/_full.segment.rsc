1:"$Sreact.fragment"
2:"/_next/static/chunks/2bmy1xsxkpnto.js"
3:I[90960,["$2"],"default"]
4:I[65360,["$2"],"default"]
9:"/_next/static/chunks/0wk_t67d4u4c_.js"
a:"/_next/static/chunks/3tafva6lk_3bv.js"
b:I[88392,["$2","$9","$a"],"CasaItalyMenu"]
11:"ViewportBoundary"
12:I[23557,["$2"],"$11"]
14:"MetadataBoundary"
15:I[23557,["$2"],"$14"]
16:"$Sreact.suspense"
19:I[51213,["$2"],"default",1]
:HL["/_next/static/chunks/41kx01fu2bdyt.css","style"]
:HL["/_next/static/media/Vazirmatn_variable-s.p.3knf6dhh8xxk6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/chunks/1wsvt0bf_o2rc.css","style"]
5:X
7:X
10:X
8:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":[["$","$Lb",null,{"products":[{"id":"meatball","name":"میت‌بال","englishName":"MEATBALL","category":"meat","image":"/brands/pizza/cavasaitaly/products/cutouts/meatball.webp","imageAlt":"پیتزای میت‌بال با ریحان تازه و گوجه","imageWidth":900,"imageHeight":900,"description":"میت‌بال، پنیر کش‌دار و عطر ریحان تازه؛ یک ترکیب ایتالیاییِ دوست‌داشتنی.","ingredients":["میت‌بال","موزارلا","گوجه","ریحان تازه"]},{"id":"steak","name":"سیر و استیک","englishName":"STEAK & GARLIC","category":"meat","image":"/brands/pizza/cavasaitaly/products/cutouts/steak.webp","imageAlt":"پیتزای سیر و استیک با برش‌های گوشت و پیازچه","imageWidth":900,"imageHeight":900,"description":"برش‌های استیک روی پنیر، با عطر سیر و تازگی پیازچه؛ پر از طعم، تا آخرین برش.","ingredients":["استیک","سیر","پنیر","پیازچه"]},{"id":"chicken","name":"مرغ و اسفناج","englishName":"CHICKEN & SPINACH","category":"poultry","image":"/brands/pizza/cavasaitaly/products/cutouts/chicken.webp","imageAlt":"پیتزای مرغ و اسفناج با لبه‌های برشته","imageWidth":900,"imageHeight":900,"description":"مرغ، اسفناج و پنیر روی خمیر لطیف و برشته؛ ساده، خوش‌عطر و دل‌چسب.","ingredients":["مرغ","اسفناج","پنیر"]},{"id":"bacon","name":"بیکن و قارچ","englishName":"BACON & MUSHROOM","category":"meat","image":"/brands/pizza/cavasaitaly/products/cutouts/bacon.webp","imageAlt":"پیتزای بیکن و قارچ با سبزی تازه","imageWidth":900,"imageHeight":900,"description":"بیکن و قارچ در کنار پنیر و سبزی تازه؛ ترکیبی آشنا با حال‌وهوای کازا.","ingredients":["بیکن","قارچ","پنیر","سبزی تازه"]},{"id":"eggplant","name":"بادمجان و پاپریکا","englishName":"EGGPLANT & PAPRIKA","category":"vegetarian","image":"/brands/pizza/cavasaitaly/products/cutouts/eggplant.webp","imageAlt":"پیتزای بادمجان و پاپریکا با روکولای تازه","imageWidth":900,"imageHeight":900,"description":"بادمجان، پاپریکا و یک مشت سبزی تازه؛ یک انتخاب رنگی برای سلیقه‌های سبز.","ingredients":["بادمجان","پاپریکا","پنیر","روکولا"]},{"id":"brisket","name":"بریسکت","englishName":"BRISKET","category":"meat","image":"/brands/pizza/cavasaitaly/products/cutouts/brisket.webp","imageAlt":"پیتزای بریسکت با حلقه‌های پیاز و فلفل","imageWidth":900,"imageHeight":900,"description":"بریسکت، حلقه‌های پیاز و پنیر روی خمیر ناپولیتن؛ یک برش با شخصیت.","ingredients":["بریسکت","پیاز","فلفل","پنیر"]},{"id":"pesto","name":"بوقلمون پستو","englishName":"TURKEY & PESTO","category":"poultry","image":"/brands/pizza/cavasaitaly/products/cutouts/pesto.webp","imageAlt":"پیتزای بوقلمون پستو با گوجه و پنیر","imageWidth":900,"imageHeight":900,"description":"عطر پستو، بوقلمون و گوجه در کنار پنیر؛ طعمی تازه از آشپزخانهٔ ایتالیایی.","ingredients":["بوقلمون","پستو","گوجه","پنیر"]}]}],["$Lc","$Ld","$Le"],"$Lf"]}],"p":true,"v":"$10"}}]]
6:[["children",{"s":"Menu","h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$7"},"c":"$Q8"}]]
18:X
1a:X
1b:X
0:{"P":null,"c":["","Menu"],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/41kx01fu2bdyt.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/2bmy1xsxkpnto.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"fa","dir":"rtl","className":"K6HPDG_variable","children":["$","body",null,{"children":["$","div",null,{"lang":"fa","dir":"rtl","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]}]]}],"p":true,"v":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[null,["$","$L12",null,{"children":"$L13"}],["$","$L15",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$16",null,{"name":"Next.Metadata","children":"$L17"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$18"}},"m":"$undefined","G":["$19",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/41kx01fu2bdyt.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$1a","s":"$1b","a":"$@1c","l":"$undefined","p":"$undefined","d":"$undefined","b":"eW4u2O-oHQjGPlPeUhapw","u":"$@1d"}
1e:I[23557,["$2"],"OutletBoundary"]
7:C
c:["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1wsvt0bf_o2rc.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]
d:["$","script","script-0",{"src":"/_next/static/chunks/0wk_t67d4u4c_.js","async":true,"nonce":"$undefined"}]
e:["$","script","script-1",{"src":"/_next/static/chunks/3tafva6lk_3bv.js","async":true,"nonce":"$undefined"}]
f:["$","$L1e",null,{"children":["$","$16",null,{"name":"Next.MetadataOutlet","children":"$@1f"}]}]
1b:300
13:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
17:[["$","title","0",{"children":"کازا ایتالی | یک برش از ایتالیا"}],["$","meta","1",{"name":"description","content":"منوی پیتزاهای ناپولیتن کازا ایتالی؛ یک سفر کوچک به ایتالیا، در قلب اردبیل."}]]
1f:null
1b:C
18:C
1a:C
10:C
5:C
1d:false
1c:null
