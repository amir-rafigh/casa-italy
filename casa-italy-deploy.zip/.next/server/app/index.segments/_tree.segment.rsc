:HL["/_next/static/chunks/41kx01fu2bdyt.css","style"]
:HL["/_next/static/media/Vazirmatn_variable-s.p.3knf6dhh8xxk6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/chunks/1km42f4d3ih8k.css","style"]
1:[["children",{"s":"__PAGE__","h":49314}]]
0:{"b":"eW4u2O-oHQjGPlPeUhapw","t":{"t":{"s":"","h":49234,"c":"$Q1"}}}
